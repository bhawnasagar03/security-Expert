//  $(document).ready(function()
// {
//  $('#contact').click(function () {

//         var form_data = new FormData();

//         $.ajax({
//             type:"POST",
//             url:"dashboardFunction.php",
//             cache: false,
//             contentType: false,
//             processData: false,
//             data:form_data,
//             success: function (data) {
//                 // $('.inbox_class').html(data);
//                 console.log(data);
//             }
//         });

//         // location.href='?page=inbox';


//     });
//  }); //end of document ready

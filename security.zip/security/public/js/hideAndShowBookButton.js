// $(document).ready(function(){
	
// 	$(".cancelGuard").hide();
    
// // for(let i=0; i<=$value.length; i++)
// // {
//     $(".bookGuard").click(function(){
//         alert('sjnfwjn');
//         this.hide();
//         //$($(this).(".cancelGuard")).show();
//        // this.show();

//     });
//     $(".cancelGuard").click(function(){
//         $(".cancelGuard").hide();
//         $(".bookGuard").show();
//     });
// // }

// });
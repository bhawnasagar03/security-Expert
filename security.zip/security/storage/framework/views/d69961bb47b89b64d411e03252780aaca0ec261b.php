<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php if(session()->has('message')): ?>
				    <div class="alert alert-success">
				        <?php echo e(session()->get('message')); ?>

				    </div>
				<?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="signupSelection">
					<a href="<?php echo e(route('customerRegister')); ?>">Signup as Customer</a>
				</div>
			</div>
			<div class="col-md-6">
				<div class="signupSelection">
				<a href="<?php echo e(route('guardSignup')); ?>">Signup as Guard</a>
				</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
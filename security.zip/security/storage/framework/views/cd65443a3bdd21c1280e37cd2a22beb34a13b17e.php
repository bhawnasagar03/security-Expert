<?php $__env->startComponent('mail::message'); ?>
# You Cancel this guard

Dear User you recently cancel your guard booking.

<?php $__env->startComponent('mail::button', ['url' => URL::route('customerLogin')]); ?>
View Cancelation
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

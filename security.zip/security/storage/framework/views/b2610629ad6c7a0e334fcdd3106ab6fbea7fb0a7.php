<?php $__env->startSection('searchHome'); ?>
<div class="container">
<div class="row">
    <div class="col-md-12">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
    <div class="row justify-content-center">
        <div class="col-md-12">
                    <div class=" dashboard" id="dashboard">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container">
                    <div class="row">

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-sm-6 col-md-4 border">
                        <div class="thumbnail">
                          <img src="<?php echo e(asset($value->guardProfile->image)); ?>" alt="..." class="img-responsive">
                          <div class="caption" id="caption">
                            <h3><?php echo e($value->fname); ?></h3>
                            <h3><?php echo e($value->email); ?></h3>
                            <?php if(Route::has('login')): ?>
                             <?php if(Auth::check()): ?>
                            <div class="caption">
                            <a href="<?php echo e(route('guardWishlist',['id'=>$value->id])); ?>" class="btn btn-default pull-left" role="button");"><i class="fa fa-heart"></i></a>
                            <form action="<?php echo e(url('/addToWishlist')); ?>">
                            <?php echo e(csrf_field()); ?>

                              <?php if($value->guardProfile->vailable==1): ?>
                                <input type="hidden" name="guard_id" value="<?php echo e($value->id); ?>">
                                <input type="hidden" name="guard_email" value="<?php echo e($value->email); ?>">
                                <button type="submit" hidden="hidden" value="<?php echo e($value->id); ?>" class="btn btn-default pull-right bookGuard" name="gurdId">Book Guard</button>
                            <?php else: ?>
                                 <input type="hidden" name="guard_id" value="<?php echo e($value->id); ?>">
                                <input type="hidden" name="guard_email" value="<?php echo e($value->email); ?>">
                                <button type="submit" value="<?php echo e($value->id); ?>" class="btn btn-default pull-right bookGuard" name="gurdId">Book Guard</button>
                            <?php endif; ?>
                            </form>
                            <form action="<?php echo e(url('/cancelGuard')); ?>">
                            <?php if($value->guardProfile->vailable==0): ?>
                            <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="guard_id" value="<?php echo e($value->id); ?>">
                                <input type="hidden" name="guard_email" value="<?php echo e($value->email); ?>">
                                <button type="submit" hidden="hidden" value="$value->id" name="gurdId" class="btn btn-danger pull-right cancelGuard">Cancel</button>
                            <?php else: ?>
                                <input type="hidden" name="guard_id" value="<?php echo e($value->id); ?>">
                                <input type="hidden" name="guard_email" value="<?php echo e($value->email); ?>">
                            <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($val->book_id==Auth::user()->id && $val->guard_id==$value->guardProfile->user_id): ?>
                                <button type="submit" value="$value->id" name="gurdId" class="btn btn-danger pull-right cancelGuard">Cancel</button>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if($val2->cancel_id==Auth::user()->id && $val->guard_id==$value->guardProfile->user_id): ?>
                                 <h6>not avilable</h6>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </form>
                            </div>
                            <?php else: ?>
                            <a href="<?php echo e(route('customerRegister')); ?>" class="pull-right">Login/Signup</a>
                              <?php endif; ?>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    

                    </div>
                   
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startComponent('mail::message'); ?>
# Got a New Job!!!

You got a new job offer  .

<?php $__env->startComponent('mail::button', ['url' => URL::route('customerLogin')]); ?>
Viwe Order
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

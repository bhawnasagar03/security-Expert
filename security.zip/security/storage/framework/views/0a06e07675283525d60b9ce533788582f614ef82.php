<?php $__env->startSection('content'); ?>
<div class="text-wrapper">
    <div class="title" data-content="404">
        404
    </div>

    <div class="subtitle">
        Oops, There is no Guard exist!!!!.
    </div>

    <div class="buttons">
        <a class="button" href="<?php echo e(route('welcome')); ?>" id="logInBtn">Go to homepage</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.errorLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
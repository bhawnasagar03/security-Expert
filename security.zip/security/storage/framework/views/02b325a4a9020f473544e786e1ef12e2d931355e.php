<?php $__env->startComponent('mail::message'); ?>
# Your job has been canceled by User

Dear Guard now you will get a new job soon 
Have a nice day.

<?php $__env->startComponent('mail::button', ['url' => URL::route('customerLogin')]); ?>
View Cancelation
<?php echo $__env->renderComponent(); ?>


Thanks$Regards<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

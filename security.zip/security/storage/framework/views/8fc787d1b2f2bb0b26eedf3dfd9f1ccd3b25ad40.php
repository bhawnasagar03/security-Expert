<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                    <div class=" dashboard">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container">
                    <div class="row">
                     
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                      <div class="col-sm-6 col-md-5 border">
                        <div class="thumbnail">
                          <img src="https://cdn3.iconfinder.com/data/icons/gray-user-toolbar/512/colonel-512.png" alt="..." class="img-responsive">
                          <div class="caption">
                            <h3><?php echo e($value->loc1); ?></h3>
                            <h3><?php echo e($value->email); ?></h3>
                            <?php if(Route::has('login')): ?>
                             <?php if(Auth::check()): ?>
                            <div>
                            <a href="<?php echo e(route('guardWishlist',['id'=>$value->id])); ?>" class="btn btn-default pull-left" role="button" onclick="alert("hgvjyguyjgfu");"><i class="fa fa-heart"></i></a>
                            
                            <form action="<?php echo e(url('/addToWishlist')); ?>">
                            <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="guard_id" value="<?php echo e($value->id); ?>">
                                <input type="hidden" name="guard_email" value="<?php echo e($value->email); ?>">
                                <button type="submit"  value="" class="btn btn-default pull-right">Book Guard</button>
                            </form>
                            
                            <!-- <a href="<?php echo e(route('bookGuard')); ?>" class="btn btn-success">Book This guard</a> -->
                            </div>
                            <?php else: ?>
                            <a href="<?php echo e(route('customerRegister')); ?>" class="pull-right">Login/Signup</a>
                              <?php endif; ?>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                  <!--  <div class="modal fade" id="myModal" tabindex="1" role="dialog">
                     <div class="modal-dialog" role="document">
                       <div class="modal-content">
                         <div class="modal-header">
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                           <h4 class="modal-title">Wishlists</h4>
                         </div>
                         <div class="modal-body">
                           <p>This Guard Added to your Wishlist!....</p>
                         </div>
                         <div class="modal-footer">
                           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                           <button type="button" class="btn btn-primary" style="display:none;">Save changes</button>
                         </div>
                       </div><!-- /.modal-content -->
                    <!--  </div> --><!-- /.modal-dialog -->
                   <!-- </div> --><!-- /.modal -->

                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> Guard Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="thumbnail">
          <img src="<?php echo e(asset($data->guardProfile->image)); ?>" class="img-responsive">
            <div class="form-group">
                <strong>First Name: <?php echo e($data->fname); ?>  <?php echo e($data->lname); ?></strong>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Email: <?php echo e($data->email); ?></strong>
            
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Phone: <?php echo e($data->phone); ?></strong>
               
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Job Type: <?php echo e($data->guardProfile->jobType); ?></strong>
            </div>
        </div><div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Locations: <?php echo e($data->preferedLocation->loc1); ?>, <?php echo e($data->preferedLocation->loc2); ?>, <?php echo e($data->preferedLocation->loc3); ?>, <?php echo e($data->preferedLocation->loc4); ?></strong>
            </div>
        </div>
       
    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
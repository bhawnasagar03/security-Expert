<?php $__env->startComponent('mail::message'); ?>
# Book Guard Conformed..

Thanks for book the **guard**.

<?php $__env->startComponent('mail::button', ['url' => URL::route('customerLogin')]); ?>
Contact This Guard
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
